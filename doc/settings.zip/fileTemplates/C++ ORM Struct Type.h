#parse("C File Header JTAX.h")
#set($DIRECTORY_HIERARCHY = $PROJECT_NAME)
#set($ONLY_HEADER = $PROJECT_NAME)
#set($NAME_SPACE = $PROJECT_NAME)
#set($DIR_LIST = $DIR_PATH.split("/"))
#set($DIR = "")
#set($foreach = "")
#if ($DIR_LIST.isEmpty())
    #set($INCLUDE_COUNT = -1)
#else
    #foreach($DIR in $DIR_LIST)
        #if(!($DIR == "include") && !($DIR == "src"))
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
            #set($ONLY_HEADER = $ONLY_HEADER + "_" + $DIR)
            #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
        #else
            #if($foreach.hasNext)
                #set($INCLUDE_COUNT = $foreach.index + 1)
            #else
                #set($INCLUDE_COUNT = $foreach.index - 1)
            #end
        #end
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $NAME)
#set($ONLY_HEADER = $ONLY_HEADER + "_" + $NAME + "_H")
#if ($INCLUDE_COUNT < 0)
    #set($MAIN_PROJECT_NAME = $PROJECT_NAME)
#else
    #set($MAIN_PROJECT_NAME = $DIR_LIST.get($INCLUDE_COUNT))
#end

#pragma once 

// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
#[[#define]]# CRTP_NAME ${NAME}CRTP
#[[#define]]# PROPERTY_DEF(PROP_TYPE, PROP_NAME, PTR_TYPE, PTR_NAME, DEFAULT) \
    PROP_TYPE PROP_NAME{DEFAULT};                                       \
    static auto PTR_NAME() -> PTR_TYPE DERIVED::* {                     \
        return static_cast<PTR_TYPE DERIVED::*>(                        \
            reinterpret_cast<PTR_TYPE CRTP_NAME::*>(                    \
                &CRTP_NAME::PROP_NAME                                   \
            )                                                           \
        );                                                              \
    }
// endregion

namespace ${NAME_SPACE} {
    template<typename DERIVED>
    struct ${NAME}CRTP {
        /*!
         * @brief 获取当前类型列
         * @return 类型列Tuple
         */
        static auto columns() {
            // return std::tuple_cat(
            //     Base::columns(),
            //     std::make_tuple(
            //         sqlite_orm::make_column("attribute", ATTRIBUTE())
            //     )
            // );
            return std::make_tuple(
            );
        }

        /*!
         * @brief 获取表名称
         * @return TableName
         */
        constexpr static auto table_name() -> const char * {
            return "${NAME}";
        }

        /*!
         * @brief 获取表Schema
         * @return TableSchema
         */
        static auto schema() {
            return std::apply([](auto &&... args) {
                return sqlite_orm::make_table<DERIVED>(table_name(), std::forward<decltype(args)>(args)...);
            }, columns());
        }
    };
    struct ${NAME} : ${NAME}CRTP<${NAME}> {
    };
}
#[[#undef]]# PRETTY_FILE_NAME
#[[#undef]]# CRTP_NAME
#[[#undef]]# PROPERTY_DEF
#parse("C File Header.h")
#set($DIRECTORY_HIERARCHY = "ModelDevelop")
#set($ONLY_HEADER = "ModelDevelop")
#set($NAME_SPACE = "ModelDevelop")
#set($DIR_LIST = $DIR_PATH.split("/"))
#set($DIR = "")
#set($foreach = "")
#if ($DIR_LIST.isEmpty())
    #set($INCLUDE_COUNT = -1)
#else
    #foreach($DIR in $DIR_LIST)
        #if(!($DIR == "include") && !($DIR == "src"))
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
            #set($ONLY_HEADER = $ONLY_HEADER + "_" + $DIR)
            #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
        #else
            #if($foreach.hasNext)
                #set($INCLUDE_COUNT = $foreach.index + 1)
            #else
                #set($INCLUDE_COUNT = $foreach.index - 1)
            #end
        #end
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $NAME)
#set($ONLY_HEADER = $ONLY_HEADER + "_" + $NAME + "_H")
#if ($INCLUDE_COUNT < 0)
    #set($MAIN_PROJECT_NAME = $PROJECT_NAME)
#else
    #set($MAIN_PROJECT_NAME = $DIR_LIST.get($INCLUDE_COUNT))
#end

#pragma once 

// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
#[[#include]]# "CommonStructs.h"
#[[#include]]# <Eigen/Core>
#[[#include]]# <Eigen/Dense>
#[[#include]]# "CoordinateHelper.h"
#[[#include]]# "State.h"
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
// endregion

namespace ${NAME_SPACE} {
class IMU {
// region USING/FRIEND
    private:
// endregion

// region Constructor
    public:
        IMU() = default;

        ~IMU() = default;

// endregion

// region Public Attributes
    public:
// endregion

// region Public Methods
    public:
        /*!
         * @brief 获取imu信息
         * @param state 自身状态
         * @param total_acc_ecf ecf系下和力 后续减去重力作为加表输出
         * @return
         */
        ImuInfo getImuInfoBody(const State &state, const Eigen::Vector3d &total_acc_ecf);

// endregion

// region Get/Set选择器
    public:
// endregion

// region Private Attributes
    private:
// endregion

// region Private Methods
    private:
// endregion
    };
}
#[[#undef]]# PRETTY_FILE_NAME
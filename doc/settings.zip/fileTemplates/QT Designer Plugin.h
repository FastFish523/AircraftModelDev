#set($DIRECTORY_HIERARCHY = $PROJECT_NAME)
#set($INAME_SPACE = $NAME_SPACE)
#set($INAME = "${NAME}Plugin")
#set($DIR_LIST = $DIR_PATH.split("/"))
#set($DIR = "")
#set($foreach = "")
#if (!($DIR_LIST.isEmpty()))
    #foreach($DIR in $DIR_LIST)
        #if(!($DIR == "include") && !($DIR == "src"))
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
        #end
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $INAME + ".h")
#parse("C File Header.h")

#pragma once 

// region Include
// region QT/STL
#[[#include]]# <QtUiPlugin/QDesignerCustomWidgetInterface>
// endregion
// region ThirdParty
// endregion
// region Self
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
#[[#ifdef]]# _WIN32
#[[#ifdef]]# ${NAME}Plugin_Build
#[[#define]]# Dll_Export_Import Q_DECL_EXPORT
#[[#else]]#
#[[#define]]# Dll_Export_Import Q_DECL_IMPORT
#[[#endif]]#
#[[#else]]#
#[[#define]]# Dll_Export_Import
#[[#endif]]#
// endregion

namespace ${NAME_SPACE} {
class Dll_Export_Import $INAME final : public QObject, public QDesignerCustomWidgetInterface {
    Q_OBJECT
    Q_INTERFACES(QDesignerCustomWidgetInterface)
    #[[#if]]# QT_VERSION >= 0x050000
    //Q_PLUGIN_METADATA(IID "org.qt-project.Qt.$INAME")
    #[[#endif]]# // QT_VERSION >= 0x050000

public:
    /*!
     * @brief Constructor
     * @params parent Parent Object
     */
    explicit $INAME(QObject *parent = nullptr);
    
    /*!
     * @brief Is Container
     */
    [[nodiscard]]
    auto isContainer() const -> bool override;

    /*!
     * @brief Is Initialized
     */
    [[nodiscard]]
    auto isInitialized() const -> bool override;

    /*!
     * @brief Get Icon
     */
    [[nodiscard]]
    auto icon() const -> QIcon override;

    /*!
     * @brief Get Dom Xml
     */
    [[nodiscard]]
    auto domXml() const -> QString override;

    /*!
     * @brief Get Group Name
     */
    [[nodiscard]]
    auto group() const -> QString override;

    /*!
     * @brief Get Include File Path
     */
    [[nodiscard]]
    auto includeFile() const -> QString override;

    /*!
     * @brief Get Name
     */
    [[nodiscard]]
    auto name() const -> QString override;

    /*!
     * @brief Get Tool Tip
     */
    [[nodiscard]]
    auto toolTip() const -> QString override;

    /*!
     * @brief Get Whats This
     */
    [[nodiscard]]
    auto whatsThis() const -> QString override;

    /*!
     * @brief Create Widget Instance
     */
    auto createWidget(QWidget *parent) -> QWidget * override;

    /*!
     * @brief Initialize
     */
    auto initialize(QDesignerFormEditorInterface *core) -> void override;

private:
    /*!
     * @brief Initialized
     */
    bool _initialized = false;
};
}
#[[#undef]]# Dll_Export_Import
#[[#undef]]# PRETTY_FILE_NAME
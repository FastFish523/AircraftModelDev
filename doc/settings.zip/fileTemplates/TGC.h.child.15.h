#parse("C File Header.h")
#set($DIRECTORY_HIERARCHY = "ModelDevelop")
#set($ONLY_HEADER = "ModelDevelop")
#set($NAME_SPACE = "ModelDevelop")
#set($DIR_LIST = $DIR_PATH.split("/"))
#set($DIR = "")
#set($foreach = "")
#if ($DIR_LIST.isEmpty())
    #set($INCLUDE_COUNT = -1)
#else
    #foreach($DIR in $DIR_LIST)
        #if(!($DIR == "include") && !($DIR == "src"))
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
            #set($ONLY_HEADER = $ONLY_HEADER + "_" + $DIR)
            #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
        #else
            #if($foreach.hasNext)
                #set($INCLUDE_COUNT = $foreach.index + 1)
            #else
                #set($INCLUDE_COUNT = $foreach.index - 1)
            #end
        #end
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $NAME)
#set($ONLY_HEADER = $ONLY_HEADER + "_" + $NAME + "_H")
#if ($INCLUDE_COUNT < 0)
    #set($MAIN_PROJECT_NAME = $PROJECT_NAME)
#else
    #set($MAIN_PROJECT_NAME = $DIR_LIST.get($INCLUDE_COUNT))
#end

#pragma once 

// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
#[[#include]]# "CommonStructs.h"
#[[#include]]# <cstdio>
#[[#include]]# <string>
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
// endregion

namespace ${NAME_SPACE} {
class Missile;
    class FileSaver {
// region USING/FRIEND
    private:
// endregion

// region Constructor
    public:
        explicit FileSaver(const std::string& path);

        ~FileSaver() ;

// endregion

// region Public Attributes
    public:
// endregion

// region Public Methods
    public:
        void save_traj(const Missile *missile);

        void save_aero(const Missile *missile);

// endregion

// region Get/Set选择器
    public:
// endregion

// region Private Attributes
    private:
        /*!
         * @brief 文件存储
         */
        std::string _directory = {};
        /*!
         * @brief 弹道文件的指针
         */
        FILE *fp_traj = nullptr;
        /*!
         * @brief 气动导数文件的指针
         */
        FILE *fp_aero = nullptr;
// endregion

// region Private Methods
    private:
        auto result_fp_aero() -> FILE *;

        auto result_fp_traj() -> FILE *;

// endregion
    };
}
#[[#undef]]# PRETTY_FILE_NAME
#parse("C File Header.h")
#set($DIRECTORY_HIERARCHY = "ModelDevelop")
#set($NAME_SPACE = "ModelDevelop")
#set($DIR_LIST = $DIR_PATH.split("/"))
#foreach($DIR in $DIR_LIST)
    #if(!($DIR == "include") && !($DIR == "src"))
        #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
        #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $NAME)
// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
#[[#include]]# "${NAME}/IMU.h"
// endregion
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
// endregion

// region Using NameSpace

// endregion

namespace ${NAME_SPACE} {
// region Static Attributes Init
// endregion

// region USING/FRIEND
// endregion

// region Constructor
// endregion

// region Public Methods
    ImuInfo IMU::getImuInfoBody(const State &state, const Eigen::Vector3d &total_acc_ecf) {
        ImuInfo imu_info;
        Eigen::Vector3d lla                 = ModelDevelop::Utils::CoordinateHelper::ecefToLla(state.posEcf);
        const Eigen::Vector3d gravity_accel = ModelDevelop::Utils::CoordinateHelper::calculateGravity(state.posEcf);
        const auto acc_ecf                  = (total_acc_ecf - gravity_accel).eval();
        const auto acc_nue                  = ModelDevelop::Utils::CoordinateHelper::ecefToNueAcceleration(acc_ecf, lla.x(), lla.y());

        imu_info.imu_acc_body = ModelDevelop::Utils::CoordinateHelper::nueToBodyAcceleration(acc_nue, state.qbn);

        imu_info.imu_w_xyz_body = state.wnb_b;
        imu_info.imu_ypr        = ModelDevelop::Utils::CoordinateHelper::quaternionToEuler231(state.qbn) / 57.3;
        return imu_info;
    }

// endregion

// region Get/Set选择器
// endregion

// region Private Methods
// endregion
}
#[[#undef]]# PRETTY_FILE_NAME
#set($DIRECTORY_HIERARCHY = "")
#set($NAME_SPACE = "")
#set($DIR_LIST = $DIR_PATH.split("/"))
#foreach($DIR in $DIR_LIST)
    #if(!($DIR == "include") && !($DIR == "src"))
        #if (($DIRECTORY_HIERARCHY == ""))
            #set($DIRECTORY_HIERARCHY = $DIR)
            #set($NAME_SPACE = $DIR)
        #else
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
            #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
        #end
    #end
#end

#parse("C File Header.h")

#pragma once 

// region Include
// region QT/STL
#[[#include]]# <${PARENT_CLASS}>
// endregion
// region ThirdParty
// endregion
// region Self
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "${DIRECTORY_HIERARCHY}/${NAME}.h"
#[[#if]]# defined(_WIN32) && !defined(Static${PACKAGE_NAME}_Build)
#[[#ifdef]]# Shared${PACKAGE_NAME}_Build
#[[#define]]# Dll_Export_Import Q_DECL_EXPORT
#[[#else]]#
#[[#define]]# Dll_Export_Import Q_DECL_IMPORT
#[[#endif]]#
#[[#else]]#
#[[#define]]# Dll_Export_Import
#[[#endif]]#
// endregion

${USER_BEGIN_NAMESPACE}
    class Dll_Export_Import ${NAME} : public ${PARENT_CLASS} {
// region USING/FRIEND
    Q_OBJECT
    private:
// endregion

// region Constructor
    public:
        /*!
         * @brief Construct
         * @param parent Parent widget
         */
        explicit ${NAME}(QWidget *parent = nullptr);
        
        /*!
         * @brief Deconstruct
         */
        ~${NAME}() override;
// endregion

// region Public Attributes
    public:
// endregion

// region Public Methods
    public:
// endregion

// region Getter/Setter
    public:
// endregion

// region Private Attributes
    private:
        /*!
         * @brief UI
         */
        void *_ui;
// endregion

// region Private Methods
    private:
// endregion
    };
${USER_END_NAMESPACE}
    
#undef PRETTY_FILE_NAME
#undef Dll_Export_Import
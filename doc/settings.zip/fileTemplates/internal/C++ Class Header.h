#parse("C File Header JTAX.h")
#set($DIRECTORY_HIERARCHY = $PROJECT_NAME)
#set($ONLY_HEADER = $PROJECT_NAME)
#set($NAME_SPACE = $PROJECT_NAME)
#set($DIR_LIST = $DIR_PATH.split("/"))
#set($DIR = "")
#set($foreach = "")
#if ($DIR_LIST.isEmpty())
    #set($INCLUDE_COUNT = -1)
#else
    #foreach($DIR in $DIR_LIST)
        #if(!($DIR == "include") && !($DIR == "src"))
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
            #set($ONLY_HEADER = $ONLY_HEADER + "_" + $DIR)
            #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
        #else
            #if($foreach.hasNext)
                #set($INCLUDE_COUNT = $foreach.index + 1)
            #else
                #set($INCLUDE_COUNT = $foreach.index - 1)
            #end
        #end
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $NAME)
#set($ONLY_HEADER = $ONLY_HEADER + "_" + $NAME + "_H")
#if ($INCLUDE_COUNT < 0)
    #set($MAIN_PROJECT_NAME = $PROJECT_NAME)
#else
    #set($MAIN_PROJECT_NAME = $DIR_LIST.get($INCLUDE_COUNT))
#end

#pragma once 

// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
#[[#if]]# defined(_WIN32) && !defined(Static${PACKAGE_NAME}_Build)
#[[#ifdef]]# Shared${PACKAGE_NAME}_Build
#[[#define]]# Dll_Export_Import Q_DECL_EXPORT
#[[#else]]#
#[[#define]]# Dll_Export_Import Q_DECL_IMPORT
#[[#endif]]#
#[[#else]]#
#[[#define]]# Dll_Export_Import
#[[#endif]]#
// endregion

namespace ${NAME_SPACE} {
class Dll_Export_Import ${NAME} {
// region USING/FRIEND
    private:
// endregion

// region Constructor
    public:
// endregion

// region Public Attributes
    public:
// endregion

// region Public Methods
    public:
// endregion

// region Get/Set选择器
    public:
// endregion

// region Private Attributes
    private:
// endregion

// region Private Methods
    private:
// endregion
};
}
#[[#undef]]# Dll_Export_Import
#[[#undef]]# PRETTY_FILE_NAME
#parse("C File Header JTAX.h")

#pragma once 

// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
#if (${HEADER_FILENAME})
#[[#include]]# "${HEADER_FILENAME}"
#end
// endregion
// endregion

// region Define
// endregion

// region Using NameSpace
// endregion
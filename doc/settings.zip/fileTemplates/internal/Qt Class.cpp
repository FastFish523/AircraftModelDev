#set($DIRECTORY_HIERARCHY = "")
#set($NAME_SPACE = "")
#set($DIR_LIST = $DIR_PATH.split("/"))
#foreach($DIR in $DIR_LIST)
    #if(!($DIR == "include") && !($DIR == "src"))
        #if (($DIRECTORY_HIERARCHY == ""))
            #set($DIRECTORY_HIERARCHY = $DIR)
            #set($NAME_SPACE = $DIR)
        #else
            #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
            #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
        #end
    #end
#end

#parse("C File Header.h")
// You may need to build the project (run Qt uic code generator) to get "${UI_HEADER_FILENAME}" resolved

// region Include
// region QT/STL
// endregion
// region ThirdParty
// endregion
// region Self
#[[#include]]# "${DIRECTORY_HIERARCHY}/${HEADER_FILENAME}"
#[[#include]]# "${UI_HEADER_FILENAME}"
// endregion
// endregion

// region Using NameSpace
// endregion

// region Define
#[[#define]]# THIS_UI ${NAME}Ui(_ui)
// endregion

${USER_BEGIN_NAMESPACE}
// region Static Attributes Init
// endregion

// region USING/FRIEND
    auto ${NAME}Ui(void *ui) -> Ui::${NAME} * {
        return static_cast<Ui::${NAME} *>(ui);
    }
    
// endregion

// region Constructor
    ${NAME}::${NAME}(QWidget *parent) : ${PARENT_CLASS}(parent), _ui(new Ui::${NAME}) {
        THIS_UI->setupUi(this);
    }
    
    ${NAME}::~${NAME}() {
        delete THIS_UI;
    }
    
// endregion

// region Public Methods
// endregion

// region Getter/Setter
// endregion

// region Private Methods
// endregion
${USER_END_NAMESPACE}

#undef THIS_UI

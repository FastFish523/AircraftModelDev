#if ($PRO_NAME)
cmake_minimum_required(VERSION 3.16)

#if ($VERSION && $LANGUAGES)
#项目名称
project($PRO_NAME VERSION $VERSION LANGUAGES $LANGUAGES)
#else 
    #if ($VERSION)
#项目名称
project($PRO_NAME VERSION $VERSION)
    #else
        #if ($LANGUAGES)
#项目名称
project($PRO_NAME LANGUAGES $LANGUAGES)
        #else
#项目名称
project($PRO_NAME)
        #end
    #end
#end

#设定版本
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_IMPORT_FILE_VERSION 1)

#设定CMAKE INCLUDE
include(CMakePackageConfigHelpers)
include(GNUInstallDirs)

#设置默认DEBUG版本后缀
set(CMAKE_DEBUG_POSTFIX d)

#设置默认CMAKE_BUILD_TYPE
if (NOT DEFINED CMAKE_BUILD_TYPE)
    set(CMAKE_BUILD_TYPE "Debug")
endif ()

#设定多平台相关
if (${DS}{CMAKE_CXX_COMPILER_ID} STREQUAL MSVC)
    #设定平台名称
    set(Current_Platform windows)
    #设定输出文件目录后缀
    set(CurrentOutPostfix windows)
    #设定真实输出文件目录后缀
    set(CurrentExternalPostfix ${DS}{CMAKE_BUILD_TYPE})
    #设定编码格式
    add_compile_options("$<$<CXX_COMPILER_ID:MSVC>:/source-charset:utf-8>")
    add_compile_options("$<$<CXX_COMPILER_ID:MSVC>:/execution-charset:GBK>")
else ()
    #设定平台名称
    set(Current_Platform linux)
    #设定输出文件目录后缀
    set(CurrentOutPostfix linux/${DS}{CMAKE_BUILD_TYPE})
    #设定真实输出文件目录后缀
    set(CurrentExternalPostfix "")
endif ()

#目录信息
set(OutputPath "$OUTPUT_PATH")

#头文件目录
include_directories(include)
#库文件目录
link_directories(${DS}{OutputPath}/${DS}{CurrentOutPostfix}/${DS}{CurrentExternalPostfix})

#设定可执行二进制文件的目录
set(EXECUTABLE_OUTPUT_PATH ${DS}{PROJECT_SOURCE_DIR}/${DS}{OutputPath}/${DS}{CurrentOutPostfix})
#设定存放编译出来的库文件的目录
set(LIBRARY_OUTPUT_PATH ${DS}{PROJECT_SOURCE_DIR}/${DS}{OutputPath}/${DS}{CurrentOutPostfix})

#设定INSTALL CMAKE的目录
set(CMAKE_INSTALL_CMAKE_DIR "${DS}{CMAKE_INSTALL_LIBDIR}/cmake/${DS}{PROJECT_NAME}")

#if ($PRO_NAME)
#生成CONFIG.cmake
configure_package_config_file(
        "PackageConfig.cmake.in"
        "${DS}{PROJECT_NAME}Config.cmake"
        INSTALL_DESTINATION "${DS}{CMAKE_INSTALL_CMAKE_DIR}"
)
#end

#if ($VERSION)
#生成VERSION.cmake
write_basic_package_version_file(
        "${DS}{PROJECT_NAME}Version.cmake"
        VERSION ${DS}{PROJECT_VERSION}
        COMPATIBILITY SameMajorVersion)
#end

#if ($PRO_NAME && $VERSION)
#安装CMAKE文件        
install(
        FILES "${DS}{CMAKE_CURRENT_BINARY_DIR}/${DS}{PROJECT_NAME}Config.cmake"
              "${DS}{CMAKE_CURRENT_BINARY_DIR}/${DS}{PROJECT_NAME}Version.cmake"
        DESTINATION "${DS}{CMAKE_INSTALL_CMAKE_DIR}"
        COMPONENT dev)
#else
    #if ($PRO_NAME)
#安装CMAKE文件
install(
        FILES "${DS}{CMAKE_CURRENT_BINARY_DIR}/${DS}{PROJECT_NAME}Config.cmake"
        DESTINATION "${DS}{CMAKE_INSTALL_CMAKE_DIR}"
        COMPONENT dev)
    #end
#end

#if ($PRO_NAME)
#安装库
install(
        EXPORT "${DS}{PROJECT_NAME}"
        FILE "${DS}{PROJECT_NAME}Targets.cmake"
        DESTINATION "${DS}{CMAKE_INSTALL_CMAKE_DIR}"
        COMPONENT dev)
#end

add_subdirectory(src)

#else
#end
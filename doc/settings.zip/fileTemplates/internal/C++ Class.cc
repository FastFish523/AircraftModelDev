#parse("C File Header JTAX.h")
#set($DIRECTORY_HIERARCHY = $PROJECT_NAME)
#set($NAME_SPACE = $PROJECT_NAME)
#set($DIR_LIST = $DIR_PATH.split("/"))
#foreach($DIR in $DIR_LIST)
    #if(!($DIR == "include") && !($DIR == "src"))
        #set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $DIR)
        #set($NAME_SPACE = $NAME_SPACE + "::" + $DIR)
    #end
#end
#set($DIRECTORY_HIERARCHY = $DIRECTORY_HIERARCHY + "/" + $NAME)
// region Include
// region STL
// endregion
// region ThirdParty
// endregion
// region Self
#[[#include]]# "${HEADER_FILENAME}"
// endregion
// endregion

// region Define
#[[#define]]# PRETTY_FILE_NAME "$DIRECTORY_HIERARCHY"
// endregion

// region Using NameSpace
// endregion

namespace ${NAME_SPACE} {
// region Static Attributes Init
// endregion

// region USING/FRIEND
// endregion

// region Constructor
// endregion

// region Public Methods
// endregion

// region Get/Set选择器
// endregion

// region Private Methods
// endregion
}
#[[#undef]]# PRETTY_FILE_NAME